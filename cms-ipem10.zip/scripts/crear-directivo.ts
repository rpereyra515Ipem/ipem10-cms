import { db } from '../src/db';
import { users } from '../src/db/schema';
import { hashPassword } from '../src/lib/password';
import { randomUUID } from 'crypto';
import { eq } from 'drizzle-orm';

async function main() {
  const email = 'vicedireccion@ipem10.edu.ar';
  const tempPassword = 'ClaveTemporal123!';
  const hash = await hashPassword(tempPassword);

  // Elimina si existía para actualizar rol limpiamente
  await db.delete(users).where(eq(users.email, email));

  await db.insert(users).values({
    id: randomUUID(),
    email,
    passwordHash: hash,
    fullName: 'Prof. Vicedirección IPEM 10',
    role: 'DIRECTIVO', // Rol institucional escolar
    mustChangePassword: true,
    active: true,
  });

  console.log('\n✅ Usuario DIRECTIVO creado con éxito:');
  console.log('--------------------------------------------------');
  console.log(`📧 Correo:     ${email}`);
  console.log(`🔑 Clave temp: ${tempPassword}`);
  console.log(`🛡️  Rol:        DIRECTIVO (Gestión Escolar)`);
  console.log('--------------------------------------------------\n');
}

main().then(() => process.exit(0));
